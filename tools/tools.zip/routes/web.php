<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ShortLinkController;

Route::get('/', [DashboardController::class, 'index']);

Route::get('/shortlinks', [ShortLinkController::class, 'showPage']);

Route::post('/shorten', [ShortLinkController::class, 'store']);        
Route::post('/shorten/{id}/update', [ShortLinkController::class, 'update']); 
Route::delete('/shorten/{id}', [ShortLinkController::class, 'destroy']);    

Route::get('/shorten/{id}/get', [ShortLinkController::class, 'getLink']); // AJAX fetch link for edit

Route::get('/l/{code}', [ShortLinkController::class, 'redirect']);
Route::get('/shorten/{id}/edit', function($id) {
    return redirect('/shortlinks'); // page already loads AJAX edit
});