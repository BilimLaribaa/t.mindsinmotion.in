<!DOCTYPE html>
<html>
<head>
    <title>Preview</title>
    <style>
        body, html { margin:0; height:100%; }
        iframe { width:100%; height:100%; border:none; }
    </style>
</head>
<body>
    <iframe src="<?php echo e($url); ?>"></iframe>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\t.mindsinmotion.in\tools\resources\views/preview.blade.php ENDPATH**/ ?>