

<?php $__env->startSection('content'); ?>
<main>
    <div class="container-fluid px-4">
        
        <h1 class="mt-4">Link Shortener</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Dashboard</li>
        </ol>

        <!-- Add/Edit Short Link Form -->
        <div class="card mb-4">
            <div class="card-header">
                <strong id="formTitle">Create Short Link</strong>
            </div>
            <div class="card-body">
                <form id="shortlinkForm" action="<?php echo e(url('/shorten')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" id="link_id">

                    <div class="row mb-3">
                        <div class="col-md-8">
                            <label class="form-label">Original URL</label>
                            <input type="url" name="url" id="url" class="form-control" required placeholder="https://example.com/my-form">
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Password (optional)</label>
                            <input type="text" name="password" id="password" class="form-control" placeholder="Leave empty for no protection">
                        </div>
                    </div>

                    <button class="btn btn-primary" id="formSubmit">Create Short Link</button>
                </form>
            </div>
        </div>

        <!-- Table of All Short Links -->
        <div class="card mb-4">
            <div class="card-header">
                <strong>All Shortened Links</strong>
            </div>
            <div class="card-body">

                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Short URL</th>
                            <th>Original URL</th>
                            <th>Clicks</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>

                            <td>
                               <a href="<?php echo e(url('/l/'.$link->code)); ?>" target="_blank">
                                    <?php echo e(url('/l/'.$link->code)); ?>

                                </a>
                            </td>

                            <td style="max-width:300px; word-wrap:break-word;">
                                <?php echo e($link->original_url); ?>

                            </td>

                            <td><?php echo e($link->clicks); ?></td>

                            <td><?php echo e($link->created_at->format('d M Y')); ?></td>

                            <td>
                                <!-- Edit button -->
                                <a href="<?php echo e(url('/shorten/'.$link->id.'/edit')); ?>" class="btn btn-sm btn-warning edit-btn">
                                    Edit
                                </a>

                                <!-- Delete button -->
                                <form action="<?php echo e(url('/shorten/'.$link->id)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button onclick="return confirm('Delete this link?')" class="btn btn-sm btn-danger">
                                        Delete
                                    </button>
                                </form>
                            </td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>

            </div>
        </div>

    </div>
</main>
<?php $__env->stopSection(); ?>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function(){

    // Handle Edit button click
     $('.edit-btn').click(function(e){
        e.preventDefault();

        let url = $(this).attr('href');
        let id = url.split('/').slice(-2)[0];

        $.get('/shorten/' + id + '/get', function(data){
            $('#link_id').val(data.id);
            $('#url').val(data.original_url);
            $('#password').val('');

            $('#shortlinkForm').attr('action', '/shorten/' + data.id + '/update');
            $('#formSubmit').text('Update Short Link');
            $('#formTitle').text('Edit Short Link');
        });
    });

});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\t.mindsinmotion.in\tools\resources\views/shortlink.blade.php ENDPATH**/ ?>