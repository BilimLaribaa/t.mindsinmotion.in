

<?php $__env->startSection('content'); ?>
    <div>
        hello page testing
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\t.mindsinmotion.in\tools\resources\views/dashboard.blade.php ENDPATH**/ ?>