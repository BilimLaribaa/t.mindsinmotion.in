<!DOCTYPE html>
<html>
<head>
    <title>Edit Short Link</title>
</head>
<body>
    <h1>Edit Short Link</h1>

    <form action="/shorten/<?php echo e($short->id); ?>/update" method="POST">
        <?php echo csrf_field(); ?>

        <label>Original URL:</label>
        <input type="text" name="url" value="<?php echo e($short->original_url); ?>" required><br><br>

        <label>Password (optional):</label>
        <input type="text" name="password"><br><br>

        <button type="submit">Update</button>
    </form>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\t.mindsinmotion.in\tools\resources\views/edit-shortlink.blade.php ENDPATH**/ ?>