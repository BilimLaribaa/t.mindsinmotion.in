@extends('layout')

@section('content')
    <div>
        hello page testing
    </div>
@endsection
